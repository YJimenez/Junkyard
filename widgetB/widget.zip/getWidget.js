(function() {
var useSSL = 'https:' == document.location.protocol;
var src = (useSSL ? 'https:' : 'http:') +
'//www.googletagservices.com/tag/js/gpt.js';
document.write('<scr' + 'ipt src="' + src + '"></scr' + 'ipt>');
})();

document.write('<script src="http://code.jquery.com/jquery-1.10.2.js"></sc'+'ript>');
document.write('<script src="http://www.junkyard.mx/btc/getFeeds.js"></sc'+'ript>');
document.write("<script src='http://player.ooyala.com/v3/fce2cf476df14253a15351f1727031b4'></sc"+"ript>");
document.write('<link rel="stylesheet" type="text/css" href="BTCstyle.css" />');


                   